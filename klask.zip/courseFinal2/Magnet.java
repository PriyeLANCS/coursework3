public class Magnet extends Ball{
    
    public Magnet(double x, double y, double diameter, String col, int layer) {
        super(x, y, diameter, col, layer);
    }
    public Magnet(double x, double y, double diameter, String col) {
        super(x, y, diameter, col);
    }

}
